# MakingArtisticMapsWithPython
 Making maps with Python. The contents of Lawrence.py are discussed in detail in this Medium blog: https://medium.com/@frank.ceballos/making-artistic-maps-with-python-9d37f5ea8af0
